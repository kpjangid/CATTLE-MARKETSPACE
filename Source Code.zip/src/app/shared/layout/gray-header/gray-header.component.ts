import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gray-header',
  templateUrl: './gray-header.component.html',
  styleUrls: ['./gray-header.component.css']
})
export class GrayHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
