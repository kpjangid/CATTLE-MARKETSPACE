import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-landing',
  templateUrl: './company-landing.component.html',
  styleUrls: ['./company-landing.component.css']
})
export class CompanyLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
